//Hisham Galib
//Lab 1
#include <iostream>
#include <string>
#include "ArrayBag.cpp"

using namespace std;


void bagTester(ArrayBag<int>& bag);

int main()
{
    // This is one way you can get values in the bag.
    // You could also read the values from a file.
    // You pick - but you should load up the bag with values.
    ArrayBag<int> bag;
    int items[] = {1, 33, 6, 9, 2, 65, 4, 29, 5, 8, 39, 88, 7, 25, 51, 3, 99, 14, 11, 10};

    //cout << "Adding positive integers to the bag: " << endl;
    for (int i = 0; i < 20; i++)
    {
        bag.add(items[i]);
    }  // end for

    // You will remove this sample funciton from your program
    //bagTester(bag);
    int choice = 1;
    int item,index = -1;
    bool success=false,sorted=false;
    while (choice != 6){
    	cout << "1. Display bag [enter 1]" << endl;
    	cout << "2. Add value to the bag [enter 2]" << endl;
    	cout << "3. Remove value from the bag [enter 3]" << endl;
    	cout << "4. Sort the bag [enter 4]" << endl;
    	cout << "5. Search for item [enter 5]" << endl;
    	cout << "6. Quit [enter 6]"<< endl;
    	cin >> choice;
    	/*Use a switch case for menu */
    	switch(choice){
    		case 1:
    			{
    			vector<int> v = bag.toVector(); 
				for (int i = 0;i < v.size();i++){
					cout<<v.at(i)<<" ";
				}
				cout << endl;
			}
				break;
			case 2:
				cout << "Enter the value you want to add: "<<endl;
				cin >> item;
				success = bag.add(item);
				if(success){
					cout << "Item successfully added! "<<endl;
				}
				else{
					cout << "Unable to add the item. "<<endl;
				}
				sorted = false;
				break;
			case 3:
				cout << "Enter the value you want to delete: "<<endl;
				cin >> item;
				success = bag.remove(item);
				if(success){
					cout << "Item successfully deleted! "<<endl;
				}
				else{
					cout << "Unable to delete the item. "<<endl;
				}
				break;
			case 4:
				bag.bubbleSort();
				sorted = true;
				break;
			case 5:
				if (!sorted){
					cout<<"The bag must be sorted before using the binary search. "<<endl;
				}
				else{
					cout<<"1. Use recursive binary search" <<endl;
					cout<<"2. Use iterative binary search" <<endl;
					cin >> choice;
					cout << "Enter the value you want to search for: "<<endl;
					cin >> item;
					/*Use a switch case inside for the two options*/
					switch(choice){
						case 1:
							index=bag.binarySearchRecursive(item);
							break;
						case 2:
							index = bag.binarySearchIterative(item);
							break;
					}
					if (index==-1){
						cout << "This item doesn't exist in the bag. " << endl;
					}
					else {
						cout << "The item exists in the bag at index "<< index << endl;
					}
				}
				break;
			case 6:
				cout<<"Goodbye! "<<endl;
				break;
			default:
				cout << "Incorrect choice. Try again. "<<endl;
				break;
		}
	}
    return 0;

}  // end main





